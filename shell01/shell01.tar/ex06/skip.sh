ls -l | awk 'NR % 3 == 2'
