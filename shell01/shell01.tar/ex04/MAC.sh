ifconfig | grep 'ether ' | rev | cut -c2- | rev  | cut -c8-
